class Bucles{
    public static void main(String[] args){
        
        int numeroIf = 13;

        if (numeroIf > 0){
            System.out.println("El número es positivo");
        }
        else if (numeroIf < 0){
            System.out.println("El número es negativo");
        }
        else{
            System.out.println("El número es 0");
        }

        int numeroWhile = 0;

        while (numeroWhile <= 3){
            System.out.println(numeroWhile);
            numeroWhile++;
        }

        int numeroDoWhile = 1;

        do {
            System.out.println(numeroDoWhile);
        } while (numeroDoWhile > 2);

        for (int numeroFor = 0; numeroFor <= 3; numeroFor++){
            System.out.println(numeroFor);
        }

        String estacion = "otoño";

        switch (estacion) {
            case "primavera":
                System.out.println(estacion);
                break;
            case "verano":
                System.out.println(estacion);
                break;
            case "otoño":
                System.out.println(estacion);
                break;
            case "invierno":
                System.out.println(estacion);
                break;
        
            default:
                System.out.println("No es una estación");
                break;
        }
        
    }
    
}