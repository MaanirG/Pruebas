public class App {
    public static void main(String[] args){

        //Esto de debajo se refiere a lo relacionado con la funcion de sumar número

        int resultado = Suma(10, 20, 30);

        System.out.println(resultado);


        //Esta parte de debajo se refiere a la llamada lo relacionado con los coches

        Coche miCoche = new Coche();

        miCoche.sumarPuertas();

        System.out.println(miCoche.puertas);
      
    }

    //Función para sumar números

    static int Suma(int n1, int n2, int n3){

        int resultado = n1 + n2 + n3;

        return resultado;
    }
}       

//Clase coche y sus características

class Coche {

    int puertas = 0;

    void sumarPuertas(){
        this.puertas++;
    }

}

